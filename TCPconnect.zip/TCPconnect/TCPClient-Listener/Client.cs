﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace TCPClient_Listener
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();

            CheckForIllegalCrossThreadCalls = false;

        }
        IPEndPoint IPep;
        TcpClient TcpClient;
        Stream client;
        private void btnSend_Click(object sender, EventArgs e)
        {
            Send();
            txbMessage.Text = "";
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            IPAddress IpAdd = IPAddress.Parse(txbIPhost.Text);
            int port = Int32.Parse(txbPort.Text);
            IPep = new IPEndPoint(IpAdd, port);

            TcpClient = new TcpClient();

            try
            {
                TcpClient.Connect(IPep);
                client = TcpClient.GetStream();
            }
            catch
            {
                MessageBox.Show("Không thể kết nối server!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Thread listen = new Thread(Receive);
            listen.IsBackground = true;
            listen.Start();
        }

       
        void AddMessage(string s)
        {
            lsvMessage.Items.Add(new ListViewItem() { Text = s });
        }
        void Send()
        {
            if (txbMessage.Text != string.Empty)
            {
                byte[] data = Encoding.UTF8.GetBytes(txbIPhost.Text + " : " + txbMessage.Text);
                client.Write(data, 0, data.Length);
                AddMessage(txbIPhost.Text + " : " + txbMessage.Text);
            }
        }

        void Receive()
        {
            try 
            {
                while (true)
                {
                    byte[] data = new byte[1024 * 5000];
                    client.Read(data, 0, data.Length);

                    string message = Encoding.UTF8.GetString(data);

                    AddMessage(message);
                }
            }
            catch
            {
                Close();
            } 
        }
        private void Client_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
