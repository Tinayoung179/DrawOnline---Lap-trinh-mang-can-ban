﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace SERVER
{
    public partial class Server : Form
    {
        public Server()
        {
            InitializeComponent();

            CheckForIllegalCrossThreadCalls = false;
        }

        private void Server_Load(object sender, EventArgs e)
        {
                
        }
        IPEndPoint IPep;
        TcpListener TcpListen;
        Socket client;
       


        private void btnSend_Click(object sender, EventArgs e)
        {
           
            Send(client);
            AddMessage(txbMessage.Text);
            txbMessage.Clear();
        }
        private void btnListen_Click(object sender, EventArgs e)
        {
            int port = Int32.Parse(txbPort.Text);
            client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPep = new IPEndPoint(IPAddress.Any, port);
            TcpListen = new TcpListener(IPep);
            
            Thread Listen = new Thread(() =>
            {
                try
                {
                    while (true)
                    {
                        TcpListen.Start();
                        client = TcpListen.AcceptSocket();

                        Thread receive = new Thread(Receive);
                        receive.IsBackground = true;
                        receive.Start();
                    }
                }
                catch
                {
                    IPep = new IPEndPoint(IPAddress.Any, 9999);
                    client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                }
            }
                 );

            Listen.IsBackground = true;
            Listen.Start();
            txbMessage.Clear();
        }
     

        void AddMessage(string s)
        {
            lsvMessage.Items.Add(new ListViewItem() { Text = s });
            txbMessage.Clear();
        }
        void Send(Socket client)
        {
            if (txbMessage.Text != string.Empty)
            {
                byte[] data = Encoding.UTF8.GetBytes("Server : " + txbMessage.Text);
                client.Send(data);
                AddMessage("Server : " + txbMessage.Text);
            }
        }
        void Receive()
        {
            try 
            {
                while (true)
                {
                    byte[] data = new byte[1024 * 5000];
                    client.Receive(data);

                    string message = Encoding.UTF8.GetString(data);

                    AddMessage(message);
                }
            }
            catch
            {
                client.Close();
            } 
        }
     

        private void Server_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }

      
    }
}
