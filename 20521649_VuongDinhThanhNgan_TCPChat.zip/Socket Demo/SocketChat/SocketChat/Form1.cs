﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SocketChat
{
    public partial class Form1 : Form
    {
        private Socket listener = null;
        private bool started = false;
        private int _port = 11000;
        private static int _buff_size = 2048;
        private byte[] _buffer = new byte[_buff_size];
        private Thread serverThread = null;
        private delegate void SafeCallDelegate(string text);
        public Form1()
        {
            InitializeComponent();
            listener = new Socket(SocketType.Stream, ProtocolType.Tcp);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (started)
                {
                    started = false;
                    button2.Text = "Listen";
                    serverThread = null;
                    listener.Close();
                }
                else
                {
                    serverThread = new Thread(this.listen);
                    serverThread.Start();
                   
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void listen()
        {
            listener.Bind(new IPEndPoint(IPAddress.Parse(textBox1.Text), _port));
            listener.Listen(10);
            started = true;
            //button2.Text = "Stop";
            UpdateChatHistoryThreadSafe("Start listening");
            while (started)
            {
                //Application.DoEvents();
                Socket client = listener.Accept();
                UpdateChatHistoryThreadSafe("Accept connection from " + client.RemoteEndPoint.ToString());
                int readbytes = client.Receive(_buffer);
                string s = Encoding.UTF8.GetString(_buffer);
                UpdateChatHistoryThreadSafe(s + "\n");
                //richTextBox1.Text += s;
                
            }
        }

        private void UpdateChatHistoryThreadSafe(string text)
        {
            if (richTextBox1.InvokeRequired)
            {
                var d = new SafeCallDelegate(UpdateChatHistoryThreadSafe);
                richTextBox1.Invoke(d, new object[] { text });

            }
            else
            {
                richTextBox1.Text += text + "\n";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
